// Funciones para interactuar con la API de iNaturalist
async function getPlaceId(placeName) {
    try {
        const response = await fetch(`https://api.inaturalist.org/v1/places/autocomplete?q=${encodeURIComponent(placeName)}`);
        const data = await response.json();
        
        if (data.results && data.results.length > 0) {
            return data.results[0].id;
        }
        return null;
    } catch (error) {
        console.error('Error obteniendo ID del lugar:', error);
        return null;
    }
}

async function getObservationsStats(placeId) {
    try {
        const response = await fetch(`https://api.inaturalist.org/v1/observations?place_id=${placeId}&verifiable=true&per_page=0`);
        return await response.json();
    } catch (error) {
        console.error('Error obteniendo estadísticas de observaciones:', error);
        throw error;
    }
}

async function getSpeciesCounts(placeId, params = {}) {
    try {
        const queryParams = new URLSearchParams({
            place_id: placeId,
            verifiable: 'true',
            ...params
        });
        
        const response = await fetch(`https://api.inaturalist.org/v1/observations/species_counts?${queryParams}`);
        return await response.json();
    } catch (error) {
        console.error('Error obteniendo conteo de especies:', error);
        throw error;
    }
}

async function getObservations(placeId, params = {}) {
    try {
        const queryParams = new URLSearchParams({
            place_id: placeId,
            verifiable: 'true',
            ...params
        });
        
        const response = await fetch(`https://api.inaturalist.org/v1/observations?${queryParams}`);
        return await response.json();
    } catch (error) {
        console.error('Error obteniendo observaciones:', error);
        throw error;
    }
}

async function getTaxonDetails(taxonId) {
    try {
        const response = await fetch(`https://api.inaturalist.org/v1/taxa/${taxonId}`);
        return await response.json();
    } catch (error) {
        console.error('Error obteniendo detalles del taxón:', error);
        throw error;
    }
}