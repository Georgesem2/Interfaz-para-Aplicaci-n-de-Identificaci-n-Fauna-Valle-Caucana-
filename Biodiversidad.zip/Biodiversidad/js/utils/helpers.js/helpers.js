// Funciones auxiliares para categorías e iconos
function getIconForTaxon(taxon) {
    if (!taxon || !taxon.ancestors) return 'fas fa-paw';
    
    const ancestorIds = taxon.ancestor_ids;
    
    if (ancestorIds.includes(40151)) return 'fas fa-paw'; // Mamíferos
    if (ancestorIds.includes(3)) return 'fas fa-dove'; // Aves
    if (ancestorIds.includes(26036)) return 'fas fa-staff-snake'; // Reptiles
    if (ancestorIds.includes(20978)) return 'fas fa-frog'; // Anfibios
    if (ancestorIds.includes(47158)) return 'fas fa-bug'; // Insectos
    if (ancestorIds.includes(47178)) return 'fas fa-fish'; // Peces
    if (ancestorIds.includes(47126)) return 'fas fa-seedling'; // Plantas
    
    return 'fas fa-paw';
}

function getCategoryClass(taxon) {
    if (!taxon || !taxon.ancestors) return 'other';
    
    const ancestorIds = taxon.ancestor_ids;
    
    if (ancestorIds.includes(40151)) return 'mammal';
    if (ancestorIds.includes(3)) return 'bird';
    if (ancestorIds.includes(26036)) return 'reptile';
    if (ancestorIds.includes(20978)) return 'amphibian';
    if (ancestorIds.includes(47158)) return 'insect';
    if (ancestorIds.includes(47178)) return 'fish';
    if (ancestorIds.includes(47126)) return 'plant';
    
    return 'other';
}

function getCategoryName(taxon) {
    if (!taxon || !taxon.ancestors) return 'Otro';
    
    const ancestorIds = taxon.ancestor_ids;
    
    if (ancestorIds.includes(40151)) return 'Mamífero';
    if (ancestorIds.includes(3)) return 'Ave';
    if (ancestorIds.includes(26036)) return 'Reptil';
    if (ancestorIds.includes(20978)) return 'Anfibio';
    if (ancestorIds.includes(47158)) return 'Insecto';
    if (ancestorIds.includes(47178)) return 'Pez';
    if (ancestorIds.includes(47126)) return 'Planta';
    
    return 'Otro';
}

function checkIfMigratory(commonName, scientificName) {
    if (!commonName && !scientificName) return false;
    
    const migratoryTerms = ['migratoria', 'migratory', 'migratorio', 'migrant', 'migratorius'];
    const nameToCheck = (commonName + ' ' + scientificName).toLowerCase();
    
    return migratoryTerms.some(term => nameToCheck.includes(term));
}

function showError(containerId, message) {
    const container = document.getElementById(containerId);
    container.innerHTML = `
        <div class="col-12 text-center">
            <p>${message}</p>
        </div>
    `;
}