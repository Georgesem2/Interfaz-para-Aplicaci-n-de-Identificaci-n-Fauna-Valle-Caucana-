async function loadRecentObservations(page = 1) {
    try {
        const placeId = await getPlaceId('valle del cauca');
        
        if (placeId) {
            // Obtener observaciones recientes
            const observationsResponse = await getObservations(placeId, {
                order: 'desc',
                order_by: 'created_at',
                per_page: 12,
                page: page
            });
            
            displayRecentObservations(observationsResponse.results, page);
            if (typeof updateMapWithObservations === 'function') {
                updateMapWithObservations(observationsResponse.results);
            }
        }
    } catch (error) {
        console.error('Error cargando observaciones recientes:', error);
        showError('recentObservations', 'Error cargando observaciones. Por favor, intenta nuevamente más tarde.');
    }
}

function displayRecentObservations(observations, page = 1) {
    const container = document.getElementById('recentObservations');
    
    if (!observations || observations.length === 0) {
        container.innerHTML = `
            <div class="col-12 text-center">
                <p>No se encontraron observaciones recientes.</p>
            </div>
        `;
        return;
    }
    
    let html = page === 1 ? '<div class="row">' : container.innerHTML;
    
    observations.forEach(observation => {
        const taxon = observation.taxon;
        const commonName = taxon ? (taxon.preferred_common_name || taxon.name || 'Especie no identificada') : 'Especie no identificada';
        const scientificName = taxon ? taxon.name : 'No identificado';
        const imageUrl = observation.photos && observation.photos.length > 0 ? 
            observation.photos[0].url.replace('square', 'medium') : 
            'https://via.placeholder.com/300x200?text=Imagen+no+disponible';
        const observedDate = new Date(observation.observed_on).toLocaleDateString('es-ES');
        const observer = observation.user ? observation.user.login : 'Anónimo';
        const location = observation.place_guess || 'Ubicación no especificada';
        const category = taxon ? getCategoryClass(taxon) : 'other';
        
        html += `
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="card h-100 observation-card" data-observation-id="${observation.id}" data-category="${category}">
                    <img src="${imageUrl}" class="card-img-top" alt="${commonName}">
                    <div class="card-body">
                        <h5 class="card-title">${commonName}</h5>
                        <p class="card-text text-muted"><em>${scientificName}</em></p>
                        <div class="d-flex justify-content-between text-muted small mb-2">
                            <span><i class="fas fa-calendar-alt me-1"></i> ${observedDate}</span>
                            <span><i class="fas fa-user me-1"></i> ${observer}</span>
                        </div>
                        <p class="card-text"><i class="fas fa-map-marker-alt me-1"></i> ${location}</p>
                        ${taxon ? `<span class="category-badge ${category}">${getCategoryName(taxon)}</span>` : ''}
                    </div>
                </div>
            </div>
        `;
    });
    
    html += '</div>';
    container.innerHTML = html;
}