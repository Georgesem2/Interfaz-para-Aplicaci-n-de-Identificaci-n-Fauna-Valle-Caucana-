# Biodiversidad Valle del Cauca

Sitio web para explorar la biodiversidad del Valle del Cauca, Colombia, con especial énfasis en especies migratorias.

## Estructura del Proyecto
