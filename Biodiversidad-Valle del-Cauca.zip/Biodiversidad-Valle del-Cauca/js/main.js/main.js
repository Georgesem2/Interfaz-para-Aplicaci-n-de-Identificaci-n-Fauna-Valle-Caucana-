// Inicialización de la aplicación
// Variables globales
let currentSpeciesPage = 1;
let currentObservationsPage = 1;
const resultsPerPage = 12;

// Inicialización cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    initApplication();
});

function initApplication() {
    // Inicializar módulos
    if (typeof initMap === 'function') initMap();
    if (typeof loadStatistics === 'function') loadStatistics();
    if (typeof loadFeaturedSpecies === 'function') loadFeaturedSpecies();
    if (typeof loadMigratorySpecies === 'function') loadMigratorySpecies();
    if (typeof loadRecentObservations === 'function') loadRecentObservations();
    
    // Configurar eventos
    setupEventListeners();
}

function setupEventListeners() {
    // Búsqueda
    document.getElementById('searchButton').addEventListener('click', performSearch);
    document.getElementById('searchInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });
    
    // Carga de más contenido
    document.getElementById('loadMoreSpecies').addEventListener('click', loadMoreSpecies);
    document.getElementById('loadMoreObservations').addEventListener('click', loadMoreObservations);
    
    // Controles del mapa
    document.getElementById('zoomIn').addEventListener('click', () => {
        if (typeof zoomIn === 'function') zoomIn();
    });
    document.getElementById('zoomOut').addEventListener('click', () => {
        if (typeof zoomOut === 'function') zoomOut();
    });
    
    // Filtros
    document.getElementById('migratoryFilter').addEventListener('change', function() {
        if (typeof toggleMigratoryFilter === 'function') toggleMigratoryFilter();
    });
    document.getElementById('resetFilter').addEventListener('click', function() {
        if (typeof resetFilters === 'function') resetFilters();
    });
    document.getElementById('categoryFilter').addEventListener('change', function() {
        if (typeof applyFilters === 'function') applyFilters();
    });
    document.getElementById('startDate').addEventListener('change', function() {
        if (typeof applyFilters === 'function') applyFilters();
    });
    document.getElementById('endDate').addEventListener('change', function() {
        if (typeof applyFilters === 'function') applyFilters();
    });
    
    // Botones de categorías
    document.querySelectorAll('[data-category]').forEach(button => {
        button.addEventListener('click', function() {
            const category = this.getAttribute('data-category');
            if (typeof searchByCategory === 'function') searchByCategory(category);
        });
    });
    
    // Scroll suave
    setupSmoothScroll();
}

function setupSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if (targetId !== '#') {
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
}

async function performSearch() {
    const query = document.getElementById('searchInput').value.trim();
    
    if (!query) {
        alert('Por favor, ingresa un término de búsqueda');
        return;
    }
    
    try {
        showLoading('featuredSpecies');
        if (typeof performSpeciesSearch === 'function') {
            await performSpeciesSearch(query);
        }
        document.getElementById('especies').scrollIntoView({ behavior: 'smooth' });
    } catch (error) {
        console.error('Error en la búsqueda:', error);
        alert('Error al realizar la búsqueda. Por favor, intenta nuevamente.');
    }
}

function loadMoreSpecies() {
    currentSpeciesPage++;
    if (typeof loadFeaturedSpecies === 'function') loadFeaturedSpecies(currentSpeciesPage);
}

function loadMoreObservations() {
    currentObservationsPage++;
    if (typeof loadRecentObservations === 'function') loadRecentObservations(currentObservationsPage);
}

function showLoading(containerId) {
    const container = document.getElementById(containerId);
    container.innerHTML = `
        <div class="col-12 text-center">
            <div class="loading-spinner">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Cargando...</span>
                </div>
            </div>
        </div>
    `;
}