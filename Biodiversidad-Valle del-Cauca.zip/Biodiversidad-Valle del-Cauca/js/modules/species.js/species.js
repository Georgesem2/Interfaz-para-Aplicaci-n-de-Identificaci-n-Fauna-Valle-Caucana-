async function loadFeaturedSpecies(page = 1) {
    try {
        const placeId = await getPlaceId('valle del cauca');
        
        if (placeId) {
            // Obtener especies populares del lugar
            const speciesResponse = await getSpeciesCounts(placeId, {
                order: 'desc',
                order_by: 'count',
                per_page: 12,
                page: page
            });
            
            displayFeaturedSpecies(speciesResponse.results, page);
        }
    } catch (error) {
        console.error('Error cargando especies destacadas:', error);
        showError('featuredSpecies', 'Error cargando especies. Por favor, intenta nuevamente más tarde.');
    }
}

function displayFeaturedSpecies(species, page = 1) {
    const container = document.getElementById('featuredSpecies');
    
    if (!species || species.length === 0) {
        container.innerHTML = `
            <div class="col-12 text-center">
                <p>No se encontraron especies destacadas.</p>
            </div>
        `;
        return;
    }
    
    let html = page === 1 ? '' : container.innerHTML;
    
    species.forEach(speciesItem => {
        const taxon = speciesItem.taxon;
        const commonName = taxon.preferred_common_name || taxon.name || 'Nombre no disponible';
        const scientificName = taxon.name;
        const observationCount = speciesItem.count;
        const imageUrl = taxon.default_photo ? taxon.default_photo.medium_url : 'https://via.placeholder.com/300x200?text=Imagen+no+disponible';
        const iconClass = getIconForTaxon(taxon);
        const category = getCategoryClass(taxon);
        
        // Verificar si es migratoria
        const isMigratory = checkIfMigratory(commonName, scientificName);
        const migratoryClass = isMigratory ? 'migratory-highlight' : '';
        
        html += `
            <div class="col-md-4 col-lg-3 mb-4 species-item ${migratoryClass}" data-species-id="${taxon.id}" data-category="${category}" data-migratory="${isMigratory}">
                <div class="card h-100 species-card">
                    <img src="${imageUrl}" class="card-img-top" alt="${commonName}">
                    <div class="card-body">
                        <div class="text-center">
                            <i class="${iconClass} species-icon"></i>
                        </div>
                        <h5 class="card-title">${commonName}</h5>
                        <p class="card-text text-muted"><em>${scientificName}</em></p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="badge bg-primary">${observationCount} observaciones</span>
                            <span class="category-badge ${category}">${getCategoryName(taxon)}</span>
                        </div>
                    </div>
                    <div class="card-footer bg-transparent">
                        <button class="btn btn-sm btn-outline-primary w-100 view-species-details" data-species-id="${taxon.id}">
                            <i class="fas fa-info-circle me-1"></i>Ver Detalles
                        </button>
                    </div>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
    
    // Configurar eventos para los botones de detalles
    document.querySelectorAll('.view-species-details').forEach(button => {
        button.addEventListener('click', function() {
            const speciesId = this.getAttribute('data-species-id');
            showSpeciesDetails(speciesId);
        });
    });
}

async function loadMigratorySpecies() {
    try {
        const placeId = await getPlaceId('valle del cauca');
        
        if (placeId) {
            // Buscar especies migratorias
            const migratoryTerms = ['migratoria', 'migratory', 'migratorio', 'migrant'];
            let allMigratorySpecies = [];
            
            for (const term of migratoryTerms) {
                const speciesResponse = await getSpeciesCounts(placeId, {
                    q: term,
                    per_page: 12
                });
                
                if (speciesResponse.results) {
                    allMigratorySpecies = allMigratorySpecies.concat(speciesResponse.results);
                }
            }
            
            // Eliminar duplicados
            const uniqueSpecies = allMigratorySpecies.filter((species, index, self) => 
                index === self.findIndex(s => s.taxon.id === species.taxon.id)
            );
            
            displayMigratorySpecies(uniqueSpecies);
        }
    } catch (error) {
        console.error('Error cargando especies migratorias:', error);
        showError('migratorySpeciesList', 'Error cargando especies migratorias. Por favor, intenta nuevamente más tarde.');
    }
}

function displayMigratorySpecies(species) {
    const container = document.getElementById('migratorySpeciesList');
    
    if (!species || species.length === 0) {
        container.innerHTML = `
            <div class="col-12 text-center">
                <p>No se encontraron especies migratorias.</p>
            </div>
        `;
        return;
    }
    
    let html = '';
    
    species.forEach(speciesItem => {
        const taxon = speciesItem.taxon;
        const commonName = taxon.preferred_common_name || taxon.name || 'Nombre no disponible';
        const scientificName = taxon.name;
        const observationCount = speciesItem.count;
        const imageUrl = taxon.default_photo ? taxon.default_photo.medium_url : 'https://via.placeholder.com/300x200?text=Imagen+no+disponible';
        const iconClass = getIconForTaxon(taxon);
        const category = getCategoryClass(taxon);
        
        html += `
            <div class="col-md-4 col-lg-3 mb-4">
                <div class="card h-100 species-card migratory-highlight">
                    <img src="${imageUrl}" class="card-img-top" alt="${commonName}">
                    <div class="card-body">
                        <div class="text-center">
                            <i class="${iconClass} species-icon"></i>
                        </div>
                        <h5 class="card-title">${commonName}</h5>
                        <p class="card-text text-muted"><em>${scientificName}</em></p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="badge bg-primary">${observationCount} observaciones</span>
                            <span class="category-badge ${category}">${getCategoryName(taxon)}</span>
                        </div>
                    </div>
                    <div class="card-footer bg-transparent">
                        <button class="btn btn-sm btn-outline-primary w-100 view-species-details" data-species-id="${taxon.id}">
                            <i class="fas fa-info-circle me-1"></i>Ver Detalles
                        </button>
                    </div>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
    
    // Configurar eventos para los botones de detalles
    document.querySelectorAll('#migratorySpeciesList .view-species-details').forEach(button => {
        button.addEventListener('click', function() {
            const speciesId = this.getAttribute('data-species-id');
            showSpeciesDetails(speciesId);
        });
    });
}

async function performSpeciesSearch(query) {
    const placeId = await getPlaceId('valle del cauca');
    
    if (placeId) {
        // Buscar especies que coincidan con la consulta en el Valle del Cauca
        const searchResponse = await getSpeciesCounts(placeId, {
            q: query,
            per_page: 12
        });
        
        displayFeaturedSpecies(searchResponse.results);
    }
}

async function searchByCategory(category) {
    try {
        showLoading('featuredSpecies');
        
        const placeId = await getPlaceId('valle del cauca');
        
        if (placeId) {
            // Buscar especies por categoría taxonómica en el Valle del Cauca
            let taxonId;
            switch(category) {
                case 'mammal': taxonId = 40151; break; // Mammalia
                case 'bird': taxonId = 3; break; // Aves
                case 'reptile': taxonId = 26036; break; // Reptilia
                case 'amphibian': taxonId = 20978; break; // Amphibia
                case 'insect': taxonId = 47158; break; // Insecta
                case 'plant': taxonId = 47126; break; // Plantae
                default: taxonId = null;
            }
            
            if (taxonId) {
                const searchResponse = await getSpeciesCounts(placeId, {
                    taxon_id: taxonId,
                    per_page: 12
                });
                
                displayFeaturedSpecies(searchResponse.results);
                
                // Desplazarse a la sección de especies
                document.getElementById('especies').scrollIntoView({ behavior: 'smooth' });
            }
        }
    } catch (error) {
        console.error('Error en la búsqueda por categoría:', error);
        alert('Error al realizar la búsqueda. Por favor, intenta nuevamente.');
    }
}

async function showSpeciesDetails(speciesId) {
    try {
        const taxonData = await getTaxonDetails(speciesId);
        
        if (taxonData.results && taxonData.results.length > 0) {
            const taxon = taxonData.results[0];
            const commonName = taxon.preferred_common_name || taxon.name;
            const scientificName = taxon.name;
            const imageUrl = taxon.default_photo ? taxon.default_photo.medium_url : 'https://via.placeholder.com/300x200?text=Imagen+no+disponible';
            const description = taxon.wikipedia_summary || 'No hay descripción disponible.';
            const conservationStatus = taxon.conservation_status ? taxon.conservation_status.status : 'No evaluada';
            const isMigratory = checkIfMigratory(commonName, scientificName);
            
            let html = `
                <div class="row">
                    <div class="col-md-5">
                        <img src="${imageUrl}" class="img-fluid rounded" alt="${commonName}">
                    </div>
                    <div class="col-md-7">
                        <h4>${commonName}</h4>
                        <p class="text-muted"><em>${scientificName}</em></p>
                        <p><strong>Estado de conservación:</strong> ${conservationStatus}</p>
                        <p><strong>Categoría:</strong> <span class="category-badge ${getCategoryClass(taxon)}">${getCategoryName(taxon)}</span></p>
                        ${isMigratory ? '<p><strong>Especie migratoria</strong> <i class="fas fa-dove text-warning"></i></p>' : ''}
                        <hr>
                        <h5>Descripción</h5>
                        <p>${description}</p>
                    </div>
                </div>
            `;
            
            document.getElementById('speciesModalTitle').textContent = commonName;
            document.getElementById('speciesModalBody').innerHTML = html;
            
            // Mostrar el modal
            const speciesModal = new bootstrap.Modal(document.getElementById('speciesModal'));
            speciesModal.show();
        }
    } catch (error) {
        console.error('Error cargando detalles de especie:', error);
        document.getElementById('speciesModalBody').innerHTML = '<p>Error cargando detalles de la especie.</p>';
    }
}