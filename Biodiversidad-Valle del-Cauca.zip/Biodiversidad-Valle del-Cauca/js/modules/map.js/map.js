let map;
let markersCluster;
let speciesMarkers = [];

function initMap() {
    // Coordenadas aproximadas del Valle del Cauca
    const valleDelCaucaCoords = [3.8009, -76.6413];
    
    map = L.map('map').setView(valleDelCaucaCoords, 9);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);
    
    // Inicializar el cluster de marcadores
    markersCluster = L.markerClusterGroup({
        chunkedLoading: true,
        maxClusterRadius: 50
    });
    map.addLayer(markersCluster);
    
    // Agregar un marcador para el Valle del Cauca
    L.marker(valleDelCaucaCoords).addTo(map)
        .bindPopup('Valle del Cauca, Colombia')
        .openPopup();
}

function updateMapWithObservations(observations) {
    // Limpiar marcadores anteriores
    markersCluster.clearLayers();
    speciesMarkers = [];
    
    if (!observations || observations.length === 0) return;
    
    observations.forEach(observation => {
        if (observation.geojson && observation.geojson.coordinates) {
            addObservationToMap(observation);
        }
    });
}

function addObservationToMap(observation) {
    const lat = observation.geojson.coordinates[1];
    const lng = observation.geojson.coordinates[0];
    
    const taxon = observation.taxon;
    const commonName = taxon ? (taxon.preferred_common_name || taxon.name) : 'Especie no identificada';
    const imageUrl = observation.photos && observation.photos.length > 0 ? 
        observation.photos[0].url.replace('square', 'small') : 
        'https://via.placeholder.com/75x75?text=Imagen+no+disponible';
    
    const category = taxon ? getCategoryClass(taxon) : 'other';
    const categoryName = taxon ? getCategoryName(taxon) : 'Otro';
    const observedDate = new Date(observation.observed_on).toLocaleDateString('es-ES');
    const observer = observation.user ? observation.user.login : 'Anónimo';
    
    // Crear icono personalizado basado en la categoría
    const icon = L.divIcon({
        className: `custom-marker ${category}`,
        html: `<i class="${getIconForTaxon(taxon)}"></i>`,
        iconSize: [30, 30],
        iconAnchor: [15, 15]
    });
    
    const marker = L.marker([lat, lng], { icon: icon });
    
    let popupContent = `
        <div class="map-popup">
            <img src="${imageUrl}" alt="${commonName}" style="width: 75px; height: 75px; object-fit: cover; float: left; margin-right: 10px;">
            <div>
                <strong>${commonName}</strong><br>
                ${taxon ? `<em>${taxon.name}</em><br>` : ''}
                <span class="category-badge ${category}">${categoryName}</span><br>
                <small>Observado: ${observedDate}</small><br>
                <small>Por: ${observer}</small>
            </div>
            <div style="clear: both; margin-top: 10px;">
                <button class="btn btn-sm btn-primary view-species-details" data-species-id="${taxon ? taxon.id : ''}" style="width: 100%;">
                    <i class="fas fa-info-circle me-1"></i>Ver Detalles
                </button>
            </div>
        </div>
    `;
    
    marker.bindPopup(popupContent);
    markersCluster.addLayer(marker);
    speciesMarkers.push(marker);
}

function zoomIn() {
    if (map) map.zoomIn();
}

function zoomOut() {
    if (map) map.zoomOut();
}