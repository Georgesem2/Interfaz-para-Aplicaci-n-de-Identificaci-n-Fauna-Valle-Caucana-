// Aplicar filtros al mapa
function applyFilters() {
    const category = document.getElementById('categoryFilter').value;
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    
    // En una implementación real, aquí se recargarían los datos del mapa con los filtros aplicados
    console.log('Filtros aplicados:', { category, startDate, endDate });
}

// Alternar filtro de especies migratorias
function toggleMigratoryFilter() {
    const showOnlyMigratory = document.getElementById('migratoryFilter').checked;
    const speciesItems = document.querySelectorAll('.species-item');
    
    speciesItems.forEach(item => {
        const isMigratory = item.getAttribute('data-migratory') === 'true';
        
        if (showOnlyMigratory && !isMigratory) {
            item.style.display = 'none';
        } else {
            item.style.display = 'block';
        }
    });
}

// Restablecer filtros
function resetFilters() {
    document.getElementById('migratoryFilter').checked = false;
    document.querySelectorAll('.species-item').forEach(item => {
        item.style.display = 'block';
    });
}